import { createContext, useContext, useState, ReactNode } from "react";

export type Role = "student" | "supervisor" | "admin";
export type SupervisorType = "industry" | "school";

interface User {
  name: string;
  email: string;
  role: Role;
  supervisorType?: SupervisorType;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, role: Role, supervisorType?: SupervisorType) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: () => {},
  logout: () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

const mockUsers: Record<Role, User> = {
  student: { name: "David Adibite-Daniel", email: "STU/2023/001", role: "student" },
  supervisor: { name: "Dr. Chukwu Emeka", email: "emeka@university.edu", role: "supervisor" },
  admin: { name: "Admin User", email: "admin@siwes.edu", role: "admin" },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = (_email: string, _password: string, role: Role, supervisorType?: SupervisorType) => {
    setUser({ ...mockUsers[role], supervisorType });
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
