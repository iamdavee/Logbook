
  # Web App UI Design

  This is a code bundle for Web App UI Design. The original project is available at https://www.figma.com/design/eB6GOJiKNJUWbcJKuzf3OR/Web-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  